import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, Mail, MessageCircle, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function Help() {
  return (
    <div className="min-h-screen p-6 pt-10 pb-24">
      <div className="flex items-center gap-4 mb-6">
        <Link href="/profile">
          <Button size="icon" variant="ghost" className="text-white hover:bg-white/10">
            <ArrowLeft className="h-6 w-6" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold text-white">Help & Support</h1>
      </div>

      {/* Contact Options */}
      <div className="grid grid-cols-2 gap-4 mb-8">
        <Card className="bg-white/90 border-none shadow-sm">
          <CardContent className="p-4 flex flex-col items-center justify-center gap-2 text-center h-32">
            <div className="h-10 w-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
              <Phone className="h-5 w-5" />
            </div>
            <span className="font-medium text-sm">Call Support</span>
          </CardContent>
        </Card>
        <Card className="bg-white/90 border-none shadow-sm">
          <CardContent className="p-4 flex flex-col items-center justify-center gap-2 text-center h-32">
            <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
              <MessageCircle className="h-5 w-5" />
            </div>
            <span className="font-medium text-sm">Chat with Us</span>
          </CardContent>
        </Card>
      </div>

      {/* FAQs */}
      <h2 className="text-xl font-bold text-white mb-4">Frequently Asked Questions</h2>
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-2 shadow-sm">
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="item-1" className="px-4 border-b-muted/20">
            <AccordionTrigger className="text-left font-medium">How do I accept a booking?</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              Go to the 'Bookings' tab, find the request under 'New', and click the 'Accept' button. The booking will move to the 'Active' tab.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="item-2" className="px-4 border-b-muted/20">
            <AccordionTrigger className="text-left font-medium">When do I get paid?</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              Payments are processed weekly every Monday for all completed jobs from the previous week.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="item-3" className="px-4 border-b-muted/20">
            <AccordionTrigger className="text-left font-medium">How to update my location?</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              Your location is automatically updated based on your device's GPS when you start a job. You can also manually update it in your Profile settings.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="item-4" className="px-4 border-b-0">
            <AccordionTrigger className="text-left font-medium">My drone is having issues</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              If you face technical issues during a job, please contact our support hotline immediately for assistance or a replacement unit request.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>

      <div className="mt-8 text-center">
        <p className="text-white/60 text-sm mb-2">Still need help?</p>
        <Button variant="outline" className="bg-white/10 text-white border-white/20 hover:bg-white/20 w-full">
          <Mail className="mr-2 h-4 w-4" /> Email Support
        </Button>
      </div>
    </div>
  );
}
