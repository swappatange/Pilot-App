import { useState } from "react";
import { useApp, translations } from "@/context/AppContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Calendar, User, Phone, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "@/hooks/use-toast";

const MOCK_BOOKINGS = [
  {
    id: 1,
    status: "pending",
    farmer: "Vikram Singh",
    location: "Moga, Punjab",
    crop: "Rice",
    acres: 20,
    date: "Tomorrow, 08:00 AM",
    amount: 5000,
    distance: "12 km"
  },
  {
    id: 2,
    status: "active",
    farmer: "Rajesh Kumar",
    location: "Bhatinda, Punjab",
    crop: "Wheat",
    acres: 15,
    date: "Today, 10:00 AM",
    amount: 3750,
    distance: "5 km"
  },
  {
    id: 3,
    status: "completed",
    farmer: "Amardeep Singh",
    location: "Barnala, Punjab",
    crop: "Cotton",
    acres: 10,
    date: "Yesterday, 02:00 PM",
    amount: 2500,
    distance: "25 km"
  }
];

export default function Bookings() {
  const { language } = useApp();
  const t = translations[language];
  const [activeTab, setActiveTab] = useState("new");

  const handleAction = (action: string, id: number) => {
    toast({
      title: action === "accept" ? "Booking Accepted" : "Booking Updated",
      description: `Booking #${id} has been ${action}ed.`,
    });
  };

  const BookingCard = ({ booking }: { booking: any }) => (
    <Card className="mb-4 shadow-sm border-l-4 border-l-transparent data-[status=active]:border-l-primary data-[status=completed]:border-l-muted" data-status={booking.status}>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
              <User className="h-5 w-5 text-muted-foreground" />
            </div>
            <div>
              <h3 className="font-bold">{booking.farmer}</h3>
              <div className="flex items-center text-muted-foreground text-xs mt-0.5">
                <MapPin className="h-3 w-3 mr-1" /> {booking.location} • {booking.distance}
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="font-bold text-primary">₹{booking.amount}</div>
            <div className="text-xs text-muted-foreground">{booking.acres} {t.acres}</div>
          </div>
        </div>

        <div className="bg-muted/50 rounded-lg p-3 grid grid-cols-2 gap-2 text-sm mb-4">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{booking.date}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">{t.crop}:</span>
            <span className="font-medium">{booking.crop}</span>
          </div>
        </div>

        {booking.status === "pending" && (
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="border-destructive text-destructive hover:bg-destructive/10" onClick={() => handleAction("reject", booking.id)}>
              {t.reject}
            </Button>
            <Button className="bg-primary hover:bg-primary/90" onClick={() => handleAction("accept", booking.id)}>
              {t.accept}
            </Button>
          </div>
        )}

        {booking.status === "active" && (
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="gap-2" onClick={() => window.open(`tel:9999999999`)}>
              <Phone className="h-4 w-4" /> Call
            </Button>
            <Button className="bg-green-600 hover:bg-green-700 gap-2" onClick={() => handleAction("complete", booking.id)}>
              <CheckCircle2 className="h-4 w-4" /> {t.complete_job}
            </Button>
          </div>
        )}

        {booking.status === "completed" && (
           <div className="flex items-center justify-center text-green-600 bg-green-50 py-2 rounded-md font-medium text-sm gap-2">
             <CheckCircle2 className="h-4 w-4" /> Completed Successfully
           </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="p-6 pt-10 min-h-screen">
      <h1 className="text-2xl font-bold mb-6 text-white">{t.bookings}</h1>
      
      <Tabs defaultValue="new" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6 bg-white/20 backdrop-blur-md text-white/70">
          <TabsTrigger value="new" className="data-[state=active]:bg-white data-[state=active]:text-primary">New</TabsTrigger>
          <TabsTrigger value="active" className="data-[state=active]:bg-white data-[state=active]:text-primary">Active</TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-white data-[state=active]:text-primary">Done</TabsTrigger>
        </TabsList>
        
        <TabsContent value="new" className="space-y-4">
          {MOCK_BOOKINGS.filter(b => b.status === "pending").map(booking => (
            <BookingCard key={booking.id} booking={booking} />
          ))}
          {MOCK_BOOKINGS.filter(b => b.status === "pending").length === 0 && (
            <div className="text-center py-10 text-white/60">No new bookings request</div>
          )}
        </TabsContent>
        
        <TabsContent value="active" className="space-y-4">
          {MOCK_BOOKINGS.filter(b => b.status === "active").map(booking => (
            <BookingCard key={booking.id} booking={booking} />
          ))}
        </TabsContent>
        
        <TabsContent value="history" className="space-y-4">
          {MOCK_BOOKINGS.filter(b => b.status === "completed").map(booking => (
            <BookingCard key={booking.id} booking={booking} />
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
