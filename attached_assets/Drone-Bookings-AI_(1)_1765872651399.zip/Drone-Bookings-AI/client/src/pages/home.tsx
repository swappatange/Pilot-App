import { useApp, translations } from "@/context/AppContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CloudSun, MapPin, Droplets, Wind, ArrowRight, ChevronRight } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { language } = useApp();
  const t = translations[language];

  const activeJobs = [
    { id: 1, farmer: "Rajesh Kumar", location: "Bhatinda, Punjab", crop: "Wheat", acres: 15, date: "Today, 10:00 AM" },
  ];

  return (
    <div className="p-6 space-y-6 pt-10">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-white">{t.welcome}, Operator</h1>
          <p className="text-white/80 text-sm">Ready for today's tasks?</p>
        </div>
        <Link href="/profile">
          <div className="h-10 w-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white font-bold cursor-pointer hover:bg-white/30 transition-colors border border-white/20">
            OP
          </div>
        </Link>
      </div>

      {/* Weather Widget */}
      <Card className="bg-gradient-to-r from-blue-500 to-blue-400 text-white border-none shadow-lg">
        <CardContent className="p-6 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <CloudSun className="h-6 w-6" />
              <span className="font-medium">Mostly Sunny</span>
            </div>
            <div className="text-4xl font-bold mb-1">28°C</div>
            <div className="text-blue-100 text-sm">Bhatinda, Punjab</div>
          </div>
          <div className="space-y-2 text-right">
            <div className="flex items-center justify-end gap-2 text-sm">
              <Wind className="h-4 w-4 opacity-80" />
              <span>12 km/h</span>
            </div>
            <div className="flex items-center justify-end gap-2 text-sm">
              <Droplets className="h-4 w-4 opacity-80" />
              <span>45%</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="border-none shadow-sm bg-primary/5">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground mb-1">{t.total_earnings}</div>
            <div className="text-2xl font-bold text-primary">₹2,450</div>
            <div className="text-xs text-green-600 mt-1">+12% from yesterday</div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-orange-500/5">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground mb-1">Jobs Done</div>
            <div className="text-2xl font-bold text-orange-600">4</div>
            <div className="text-xs text-muted-foreground mt-1">Today</div>
          </CardContent>
        </Card>
      </div>

      {/* Active Job / CTA */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-semibold text-lg">{t.active_bookings}</h2>
          <Link href="/bookings" className="text-primary text-sm flex items-center gap-1">
            View All <ChevronRight className="h-4 w-4" />
          </Link>
        </div>

        {activeJobs.map((job) => (
          <Card key={job.id} className="border-l-4 border-l-primary shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-bold text-lg">{job.farmer}</h3>
                  <div className="flex items-center text-muted-foreground text-sm mt-1">
                    <MapPin className="h-3 w-3 mr-1" /> {job.location}
                  </div>
                </div>
                <span className="bg-primary/10 text-primary px-2 py-1 rounded text-xs font-medium">
                  Active
                </span>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                <div>
                  <span className="text-muted-foreground block text-xs">{t.crop}</span>
                  <span className="font-medium">{job.crop}</span>
                </div>
                <div>
                  <span className="text-muted-foreground block text-xs">{t.acres}</span>
                  <span className="font-medium">{job.acres} Acres</span>
                </div>
              </div>

              <Button className="w-full" asChild>
                <Link href="/bookings">{t.complete_job}</Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
