import { useApp, translations } from "@/context/AppContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { IndianRupee, TrendingUp, CalendarDays } from "lucide-react";

const data = [
  { day: "Mon", amount: 2500 },
  { day: "Tue", amount: 3200 },
  { day: "Wed", amount: 1800 },
  { day: "Thu", amount: 4500 },
  { day: "Fri", amount: 2450 },
  { day: "Sat", amount: 5000 },
  { day: "Sun", amount: 0 },
];

export default function Earnings() {
  const { language } = useApp();
  const t = translations[language];

  return (
    <div className="p-6 pt-10 space-y-6 min-h-screen">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">{t.earnings}</h1>
        <Select defaultValue="this_week">
          <SelectTrigger className="w-[120px] bg-white/20 border-white/30 text-white backdrop-blur-sm">
            <SelectValue placeholder="Period" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="this_week">This Week</SelectItem>
            <SelectItem value="this_month">This Month</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Total Card */}
      <Card className="bg-white/20 text-white border-white/30 backdrop-blur-md">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-2 opacity-90">
            <IndianRupee className="h-5 w-5" />
            <span className="font-medium">Total Balance</span>
          </div>
          <div className="text-4xl font-bold mb-2">₹19,450</div>
          <div className="flex items-center text-sm bg-white/20 w-fit px-2 py-1 rounded-full backdrop-blur-sm">
            <TrendingUp className="h-3 w-3 mr-1" /> +15% vs last week
          </div>
        </CardContent>
      </Card>

      {/* Chart */}
      <Card className="bg-white/90 border-none shadow-lg">
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <CalendarDays className="h-4 w-4" /> Weekly Overview
          </CardTitle>
        </CardHeader>
        <CardContent className="pl-0">
          <div className="h-[200px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} margin={{ top: 0, right: 10, left: 0, bottom: 0 }}>
                <XAxis 
                  dataKey="day" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false}
                  tick={{ fill: 'hsl(var(--muted-foreground))' }} 
                />
                <Tooltip 
                  cursor={{ fill: 'transparent' }}
                  contentStyle={{ 
                    borderRadius: '8px', 
                    border: 'none', 
                    boxShadow: '0 4px 12px rgba(0,0,0,0.1)' 
                  }}
                />
                <Bar dataKey="amount" radius={[4, 4, 0, 0]}>
                   {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 4 ? 'hsl(var(--primary))' : 'hsl(var(--primary)/0.3)'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Recent Transactions List */}
      <div>
        <h3 className="font-semibold mb-4 text-white">Recent Payouts</h3>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex justify-between items-center p-4 bg-white/10 backdrop-blur-md rounded-xl border border-white/20 shadow-xs text-white">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 bg-white/20 text-white rounded-full flex items-center justify-center">
                  <IndianRupee className="h-5 w-5" />
                </div>
                <div>
                  <div className="font-medium">Weekly Payout</div>
                  <div className="text-xs text-white/60">Dec {16 - i}, 2024</div>
                </div>
              </div>
              <div className="font-bold text-white">+ ₹5,000</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
