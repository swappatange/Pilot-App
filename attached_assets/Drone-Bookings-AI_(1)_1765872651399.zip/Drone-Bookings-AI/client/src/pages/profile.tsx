import { useApp, translations } from "@/context/AppContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  User, 
  Phone, 
  MapPin, 
  Globe, 
  HelpCircle, 
  LogOut, 
  ChevronRight,
  ShieldCheck,
  Bell
} from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Profile() {
  const { user, logout, language } = useApp();
  const [, setLocation] = useLocation();
  const t = translations[language];

  const handleLogout = () => {
    logout();
    setLocation("/login");
  };

  const menuItems = [
    { icon: Globe, label: "Language", value: language === 'en' ? 'English' : 'Change', href: "/language" },
    { icon: Bell, label: "Notifications", value: "On", href: "#" },
    { icon: ShieldCheck, label: "Privacy & Security", href: "#" },
    { icon: HelpCircle, label: "Help & Support", href: "/help" },
  ];

  return (
    <div className="min-h-screen p-6 pt-10 pb-24">
      <h1 className="text-2xl font-bold text-white mb-6">Profile</h1>

      {/* Profile Card */}
      <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 mb-6 text-white flex flex-col items-center">
        <Avatar className="h-24 w-24 border-4 border-white/10 mb-4">
          <AvatarImage src="" />
          <AvatarFallback className="bg-primary text-primary-foreground text-2xl font-bold">DO</AvatarFallback>
        </Avatar>
        <h2 className="text-xl font-bold">Drone Operator</h2>
        <p className="text-white/60">+91 {user?.mobile || "98765 43210"}</p>
        
        <div className="flex items-center gap-2 mt-4 text-sm bg-white/10 px-3 py-1 rounded-full">
          <MapPin className="h-3 w-3" />
          <span>Bhatinda, Punjab</span>
        </div>
      </div>

      {/* Menu Items */}
      <div className="space-y-3">
        {menuItems.map((item, index) => (
          <Link key={index} href={item.href}>
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-4 flex items-center justify-between shadow-sm active:scale-[0.98] transition-transform">
              <div className="flex items-center gap-3 text-foreground">
                <div className="h-8 w-8 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                  <item.icon className="h-4 w-4" />
                </div>
                <span className="font-medium">{item.label}</span>
              </div>
              <div className="flex items-center gap-2">
                {item.value && <span className="text-sm text-muted-foreground">{item.value}</span>}
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Logout Button */}
      <Button 
        variant="destructive" 
        className="w-full mt-8 h-12 text-lg rounded-xl shadow-lg"
        onClick={handleLogout}
      >
        <LogOut className="mr-2 h-5 w-5" /> Logout
      </Button>
    </div>
  );
}
