import { useApp, translations } from "@/context/AppContext";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Calendar, CheckCircle2 } from "lucide-react";

const HISTORY_DATA = [
  {
    id: 101,
    farmer: "Amardeep Singh",
    location: "Barnala, Punjab",
    date: "Dec 15, 2024",
    amount: 2500,
    acres: 10,
    crop: "Cotton",
    status: "Completed"
  },
  {
    id: 102,
    farmer: "Gurpreet Singh",
    location: "Moga, Punjab",
    date: "Dec 14, 2024",
    amount: 5000,
    acres: 20,
    crop: "Wheat",
    status: "Completed"
  },
  {
    id: 103,
    farmer: "Ravi Kumar",
    location: "Bhatinda, Punjab",
    date: "Dec 12, 2024",
    amount: 1250,
    acres: 5,
    crop: "Mustard",
    status: "Completed"
  },
  {
    id: 104,
    farmer: "Suresh Patel",
    location: "Ludhiana, Punjab",
    date: "Dec 10, 2024",
    amount: 3750,
    acres: 15,
    crop: "Wheat",
    status: "Completed"
  }
];

export default function History() {
  const { language } = useApp();
  const t = translations[language];

  return (
    <div className="p-6 pt-10 min-h-screen">
      <h1 className="text-2xl font-bold mb-6 text-white">{t.history}</h1>

      <div className="space-y-4">
        {HISTORY_DATA.map((job) => (
          <Card key={job.id} className="border-none shadow-sm hover:shadow-md transition-all bg-white/95">
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-base">{job.farmer}</h3>
                  <div className="flex items-center text-muted-foreground text-xs mt-1">
                    <MapPin className="h-3 w-3 mr-1" /> {job.location}
                  </div>
                </div>
                <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">
                  <CheckCircle2 className="h-3 w-3 mr-1" /> {job.status}
                </Badge>
              </div>

              <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                <div className="flex flex-col">
                  <span className="text-xs text-muted-foreground">{t.date}</span>
                  <div className="flex items-center text-sm font-medium">
                    <Calendar className="h-3 w-3 mr-1 opacity-70" /> {job.date}
                  </div>
                </div>
                <div className="flex flex-col text-right">
                  <span className="text-xs text-muted-foreground">{t.amount}</span>
                  <span className="text-sm font-bold text-primary">₹{job.amount}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
