import { useState } from "react";
import { useLocation } from "wouter";
import { useApp, translations } from "@/context/AppContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronRight, Loader2 } from "lucide-react";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import logo from "@assets/Latest_Atomik_Logo_1765869246733.png";

export default function Login() {
  const [, setLocation] = useLocation();
  const { login, language } = useApp();
  const t = translations[language];
  const [step, setStep] = useState<"mobile" | "otp">("mobile");
  const [mobile, setMobile] = useState("");
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSendOtp = () => {
    if (mobile.length < 10) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep("otp");
    }, 1500);
  };

  const handleVerifyOtp = () => {
    if (otp.length < 6) return;
    setLoading(true);
    setTimeout(() => {
      login(mobile);
      setLocation("/home");
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col p-6">
      <div className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full">
        <div className="mb-8 text-center">
           <div className="inline-block mb-8">
             <img 
              src={logo}
              alt="Logo" 
              className="h-24 object-contain"
            />
           </div>
          <h1 className="text-2xl font-bold text-white">
            {step === "mobile" ? t.login : t.otp_verify}
          </h1>
          <p className="text-white/80 mt-2">
            {step === "mobile" 
              ? "Enter your mobile number to continue" 
              : `Enter the code sent to ${mobile}`}
          </p>
        </div>

        <AnimatePresence mode="wait">
          {step === "mobile" ? (
            <motion.div
              key="mobile"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              <div className="space-y-2">
                <label className="text-sm font-medium text-white">{t.mobile_number}</label>
                <div className="flex gap-2">
                  <div className="flex items-center justify-center px-3 border border-white/30 rounded-md bg-white/20 text-white font-medium backdrop-blur-sm">
                    +91
                  </div>
                  <Input 
                    type="tel" 
                    placeholder="98765 43210" 
                    className="text-lg tracking-wide bg-white/20 border-white/30 text-white placeholder:text-white/50 backdrop-blur-sm focus-visible:ring-white/50"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
                  />
                </div>
              </div>
              <Button 
                className="w-full h-12 text-lg bg-white text-primary hover:bg-white/90" 
                onClick={handleSendOtp}
                disabled={mobile.length < 10 || loading}
              >
                {loading ? <Loader2 className="animate-spin" /> : t.get_otp}
              </Button>
            </motion.div>
          ) : (
            <motion.div
              key="otp"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex justify-center">
                <InputOTP maxLength={6} value={otp} onChange={setOtp}>
                  <InputOTPGroup className="gap-2">
                    {[0, 1, 2, 3, 4, 5].map((i) => (
                      <InputOTPSlot 
                        key={i} 
                        index={i} 
                        className="bg-white/20 border-white/30 text-white backdrop-blur-sm h-12 w-10 md:w-12"
                      />
                    ))}
                  </InputOTPGroup>
                </InputOTP>
              </div>
              
              <Button 
                className="w-full h-12 text-lg bg-white text-primary hover:bg-white/90" 
                onClick={handleVerifyOtp}
                disabled={otp.length < 6 || loading}
              >
                {loading ? <Loader2 className="animate-spin" /> : t.verify}
              </Button>

              <button 
                onClick={() => setStep("mobile")}
                className="w-full text-sm text-white/80 hover:text-white hover:underline text-center"
              >
                Change Mobile Number
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
