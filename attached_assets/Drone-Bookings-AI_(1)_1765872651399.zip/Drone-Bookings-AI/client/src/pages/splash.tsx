import { useEffect } from "react";
import { useLocation } from "wouter";
import { useApp } from "@/context/AppContext";
import { motion } from "framer-motion";
import bgImage from "@assets/generated_images/dark_green_to_teal_gradient_with_subtle_hexagon_pattern.png";
import logo from "@assets/Latest_Atomik_Logo_1765869246733.png";

export default function Splash() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, language } = useApp();

  useEffect(() => {
    const timer = setTimeout(() => {
      if (isAuthenticated) {
        setLocation("/home");
      } else {
        setLocation("/language");
      }
    }, 5000);

    return () => clearTimeout(timer);
  }, [isAuthenticated, setLocation]);

  return (
    <div className="h-screen w-full flex items-center justify-center relative overflow-hidden">
      {/* Background decoration */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${bgImage})` }}
      />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="z-10 flex flex-col items-center"
      >
        <div className="w-[32rem] h-[16rem] flex items-center justify-center p-8">
           <img 
            src={logo}
            alt="Atomik Logo" 
            className="w-full h-full object-contain"
          />
        </div>
      </motion.div>
    </div>
  );
}
