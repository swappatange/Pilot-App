import { useLocation } from "wouter";
import { useApp, translations } from "@/context/AppContext";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

const languages = [
  { code: "en", name: "English", native: "English" },
  { code: "hi", name: "Hindi", native: "हिन्दी" },
  { code: "pa", name: "Punjabi", native: "ਪੰਜਾਬੀ" },
  { code: "mr", name: "Marathi", native: "मराठी" },
  { code: "kn", name: "Kannada", native: "ಕನ್ನಡ" },
  { code: "te", name: "Telugu", native: "తెలుగు" },
  { code: "ta", name: "Tamil", native: "தமிழ்" },
] as const;

export default function LanguageSelect() {
  const [, setLocation] = useLocation();
  const { setLanguage } = useApp();

  const handleSelect = (lang: any) => {
    setLanguage(lang);
    setLocation("/login");
  };

  return (
    <div className="min-h-screen p-6 flex flex-col">
      <div className="mt-10 mb-8">
        <h1 className="text-2xl font-bold text-white">Select Language</h1>
        <p className="text-white/80 mt-2">Choose your preferred language to continue</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {languages.map((lang, index) => (
          <motion.button
            key={lang.code}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            onClick={() => handleSelect(lang.code)}
            className="flex flex-col items-center justify-center p-6 rounded-xl border border-white/20 bg-white/10 backdrop-blur-md hover:bg-white/20 active:scale-95 transition-all shadow-sm"
          >
            <span className="text-xl font-bold text-white mb-1">{lang.native}</span>
            <span className="text-sm text-white/70">{lang.name}</span>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
