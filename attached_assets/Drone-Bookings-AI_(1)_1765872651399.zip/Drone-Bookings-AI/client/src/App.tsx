import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AppProvider } from "@/context/AppContext";
import Layout from "@/components/layout/Layout";

import Splash from "@/pages/splash";
import LanguageSelect from "@/pages/language-select";
import Login from "@/pages/login";
import Home from "@/pages/home";
import Bookings from "@/pages/bookings";
import Earnings from "@/pages/earnings";
import History from "@/pages/history";
import Profile from "@/pages/profile";
import Help from "@/pages/help";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Splash} />
        <Route path="/language" component={LanguageSelect} />
        <Route path="/login" component={Login} />
        <Route path="/home" component={Home} />
        <Route path="/bookings" component={Bookings} />
        <Route path="/earnings" component={Earnings} />
        <Route path="/history" component={History} />
        <Route path="/profile" component={Profile} />
        <Route path="/help" component={Help} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppProvider>
        <Router />
        <Toaster />
      </AppProvider>
    </QueryClientProvider>
  );
}

export default App;
