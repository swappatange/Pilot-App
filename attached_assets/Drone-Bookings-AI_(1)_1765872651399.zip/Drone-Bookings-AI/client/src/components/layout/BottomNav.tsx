import { Link, useLocation } from "wouter";
import { LayoutDashboard, Calendar, IndianRupee, History } from "lucide-react";
import { useApp, translations } from "@/context/AppContext";
import { cn } from "@/lib/utils";

export default function BottomNav() {
  const [location] = useLocation();
  const { language } = useApp();
  const t = translations[language];

  const navItems = [
    { href: "/home", icon: LayoutDashboard, label: t.dashboard },
    { href: "/bookings", icon: Calendar, label: t.bookings },
    { href: "/earnings", icon: IndianRupee, label: t.earnings },
    { href: "/history", icon: History, label: t.history },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background border-t border-border z-50 pb-safe">
      <div className="flex justify-around items-center h-16">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={cn(
                  "flex flex-col items-center justify-center w-full h-full space-y-1 active:scale-95 transition-transform",
                  isActive ? "text-primary" : "text-muted-foreground"
                )}
              >
                <item.icon
                  className={cn("h-6 w-6", isActive && "fill-current/20")}
                  strokeWidth={isActive ? 2.5 : 2}
                />
                <span className="text-[10px] font-medium">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
