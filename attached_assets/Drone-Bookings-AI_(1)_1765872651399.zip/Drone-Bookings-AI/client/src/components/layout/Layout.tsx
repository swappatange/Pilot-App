import { ReactNode } from "react";
import BottomNav from "./BottomNav";
import { useApp } from "@/context/AppContext";
import bgImage from "@assets/generated_images/dark_green_to_teal_gradient_with_subtle_hexagon_pattern.png";

export default function Layout({ children }: { children: ReactNode }) {
  const { isAuthenticated } = useApp();

  return (
    <div className="min-h-screen font-sans text-foreground pb-20 relative">
      {/* Global Background */}
      <div 
        className="fixed inset-0 z-[-1] bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${bgImage})` }}
      />
      
      <main className="max-w-md mx-auto min-h-screen relative shadow-2xl overflow-hidden backdrop-blur-[2px] bg-black/10">
        {children}
        {isAuthenticated && <BottomNav />}
      </main>
    </div>
  );
}
