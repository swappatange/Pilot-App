import React, { createContext, useContext, useState, ReactNode } from "react";

type Language = "en" | "hi" | "pa" | "mr" | "kn" | "te" | "ta";

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  isAuthenticated: boolean;
  login: (mobile: string) => void;
  logout: () => void;
  user: { mobile: string; name: string } | null;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<{ mobile: string; name: string } | null>(null);

  const login = (mobile: string) => {
    setIsAuthenticated(true);
    setUser({ mobile, name: "Drone Operator" });
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUser(null);
  };

  return (
    <AppContext.Provider
      value={{ language, setLanguage, isAuthenticated, login, logout, user }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}

export const translations = {
  en: {
    welcome: "Welcome",
    login: "Login",
    otp_verify: "Verify OTP",
    dashboard: "Dashboard",
    bookings: "Bookings",
    earnings: "Earnings",
    history: "History",
    select_language: "Select Language",
    mobile_number: "Mobile Number",
    get_otp: "Get OTP",
    verify: "Verify",
    active_bookings: "Active Bookings",
    total_earnings: "Total Earnings",
    completed: "Completed",
    pending: "Pending",
    accept: "Accept",
    reject: "Reject",
    start_job: "Start Job",
    complete_job: "Complete Job",
    date: "Date",
    amount: "Amount",
    acres: "Acres",
    crop: "Crop",
    farmer: "Farmer",
    location: "Location",
  },
  hi: {
    welcome: "नमस्ते",
    login: "लॉग इन",
    otp_verify: "OTP सत्यापित करें",
    dashboard: "डैशबोर्ड",
    bookings: "बुकिंग",
    earnings: "कमाई",
    history: "इतिहास",
    select_language: "भाषा चुनें",
    mobile_number: "मोबाइल नंबर",
    get_otp: "OTP प्राप्त करें",
    verify: "सत्यापित करें",
    active_bookings: "सक्रिय बुकिंग",
    total_earnings: "कुल कमाई",
    completed: "पूर्ण",
    pending: "लंबित",
    accept: "स्वीकार करें",
    reject: "अस्वीकार करें",
    start_job: "कार्य शुरू करें",
    complete_job: "कार्य पूरा करें",
    date: "तारीख",
    amount: "राशि",
    acres: "एकड़",
    crop: "फसल",
    farmer: "किसान",
    location: "स्थान",
  },
  pa: {
    welcome: "ਜੀ ਆਇਆਂ ਨੂੰ",
    login: "ਲੌਗ ਇਨ",
    otp_verify: "OTP ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ",
    dashboard: "ਡੈਸ਼ਬੋਰਡ",
    bookings: "ਬੁਕਿੰਗ",
    earnings: "ਕਮਾਈ",
    history: "ਇਤਿਹਾਸ",
    select_language: "ਭਾਸ਼ਾ ਚੁਣੋ",
    mobile_number: "ਮੋਬਾਈਲ ਨੰਬਰ",
    get_otp: "OTP ਪ੍ਰਾਪਤ ਕਰੋ",
    verify: "ਪੁਸ਼ਟੀ ਕਰੋ",
    active_bookings: "ਸਰਗਰਮ ਬੁਕਿੰਗ",
    total_earnings: "ਕੁੱਲ ਕਮਾਈ",
    completed: "ਮੁਕੰਮਲ",
    pending: "ਬਕਾਇਆ",
    accept: "ਸਵੀਕਾਰ ਕਰੋ",
    reject: "ਰੱਦ ਕਰੋ",
    start_job: "ਕੰਮ ਸ਼ੁਰੂ ਕਰੋ",
    complete_job: "ਕੰਮ ਪੂਰਾ ਕਰੋ",
    date: "ਮਿਤੀ",
    amount: "ਰਕਮ",
    acres: "ਏਕੜ",
    crop: "ਫਸਲ",
    farmer: "ਕਿਸਾਨ",
    location: "ਸਥਾਨ",
  },
  mr: {
    welcome: "स्वागत आहे",
    login: "लॉग इन",
    otp_verify: "OTP सत्यापित करा",
    dashboard: "डॅशबोर्ड",
    bookings: "बुकिंग",
    earnings: "कमाई",
    history: "इतिहास",
    select_language: "भाषा निवडा",
    mobile_number: "मोबाईल नंबर",
    get_otp: "OTP मिळवा",
    verify: "सत्यापित करा",
    active_bookings: "सक्रिय बुकिंग",
    total_earnings: "एकूण कमाई",
    completed: "पूर्ण",
    pending: "प्रलंबित",
    accept: "स्वीकारा",
    reject: "नकार द्या",
    start_job: "काम सुरू करा",
    complete_job: "काम पूर्ण करा",
    date: "तारीख",
    amount: "रक्कम",
    acres: "एकर",
    crop: "पीक",
    farmer: "शेतकरी",
    location: "स्थान",
  },
  kn: {
    welcome: "ಸ್ವಾಗತ",
    login: "ಲಾಗಿನ್",
    otp_verify: "OTP ಪರಿಶೀಲಿಸಿ",
    dashboard: "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
    bookings: "ಬುಕಿಂಗ್‌ಗಳು",
    earnings: "ಗಳಿಕೆ",
    history: "ಇತಿಹಾಸ",
    select_language: "ಭಾಷೆಯನ್ನು ಆರಿಸಿ",
    mobile_number: "ಮೊಬೈಲ್ ಸಂಖ್ಯೆ",
    get_otp: "OTP ಪಡೆಯಿರಿ",
    verify: "ಪರಿಶೀಲಿಸಿ",
    active_bookings: "ಸಕ್ರಿಯ ಬುಕಿಂಗ್‌ಗಳು",
    total_earnings: "ಒಟ್ಟು ಗಳಿಕೆ",
    completed: "ಪೂರ್ಣಗೊಂಡಿದೆ",
    pending: "ಬಾಕಿ ಇದೆ",
    accept: "ಒಪ್ಪಿಕೊಳ್ಳಿ",
    reject: "ತಿರಸ್ಕರಿಸಿ",
    start_job: "ಕೆಲಸ ಪ್ರಾರಂಭಿಸಿ",
    complete_job: "ಕೆಲಸ ಪೂರ್ಣಗೊಳಿಸಿ",
    date: "ದಿನಾಂಕ",
    amount: "ಮೊತ್ತ",
    acres: "ಎಕರೆ",
    crop: "ಬೆಳೆ",
    farmer: "ರೈತ",
    location: "ಸ್ಥಳ",
  },
  te: {
    welcome: "స్వాగతం",
    login: "లాగిన్",
    otp_verify: "OTP ని ధృవీకరించండి",
    dashboard: "డాష్‌బోర్డ్",
    bookings: "బుకింగ్‌లు",
    earnings: "సంపాదన",
    history: "చరిత్ర",
    select_language: "భాషను ఎంచుకోండి",
    mobile_number: "మొబైల్ సంఖ్య",
    get_otp: "OTP పొందండి",
    verify: "ధృవీకరించండి",
    active_bookings: "యాక్టివ్ బుకింగ్‌లు",
    total_earnings: "మొత్తం సంపాదన",
    completed: "పూర్తయింది",
    pending: "పెండింగ్‌లో ఉంది",
    accept: "అంగీకరించండి",
    reject: "తిరస్కరించండి",
    start_job: "పని ప్రారంభించండి",
    complete_job: "పని పూర్తి చేయండి",
    date: "తేదీ",
    amount: "మొత్తం",
    acres: "ఎకరాలు",
    crop: "పంట",
    farmer: "రైతు",
    location: "స్థానం",
  },
  ta: {
    welcome: "வரவேற்பு",
    login: "உள்நுழைய",
    otp_verify: "OTP சரிபார்க்கவும்",
    dashboard: "டாஷ்போர்டு",
    bookings: "முன்பதிவுகள்",
    earnings: "வருவாய்",
    history: "வரலாறு",
    select_language: "மொழியைத் தேர்ந்தெடுக்கவும்",
    mobile_number: "மொபைல் எண்",
    get_otp: "OTP பெறவும்",
    verify: "சரிபார்க்கவும்",
    active_bookings: "செயலில் உள்ள முன்பதிவுகள்",
    total_earnings: "மொத்த வருவாய்",
    completed: "முடிந்தது",
    pending: "நிலுவையில் உள்ளது",
    accept: "ஏற்கவும்",
    reject: "நிராகரிக்கவும்",
    start_job: "வேலையைத் தொடங்கவும்",
    complete_job: "வேலையை முடிக்கவும்",
    date: "தேதி",
    amount: "தொகை",
    acres: "ஏக்கர்",
    crop: "பயிர்",
    farmer: "விவசாயி",
    location: "இடம்",
  },
};
